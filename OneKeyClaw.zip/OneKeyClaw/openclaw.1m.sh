#!/usr/bin/env bash

# <bitbar.title>OpenClaw Dashboard Launcher</bitbar.title>
# <bitbar.version>v1.0.0</bitbar.version>
# <bitbar.author>Codex</bitbar.author>
# <bitbar.author.github>openai</bitbar.author.github>
# <bitbar.desc>One-click OpenClaw Dashboard launcher with automatic auth token fetching.</bitbar.desc>
# <bitbar.image>https://swiftbar.app/images/plugins/open.png</bitbar.image>
# <bitbar.dependencies>bash,curl,python3</bitbar.dependencies>

set -u

CONFIG_FILE="${OPENCLAW_CONFIG_FILE:-$HOME/.config/openclaw-swiftbar.env}"
CACHE_FILE="${OPENCLAW_CACHE_FILE:-$HOME/Library/Caches/SwiftBar/openclaw_token_cache.json}"
DASHBOARD_URL_DEFAULT="http://127.0.0.1:3000"
CONTROL_URL_DEFAULT=""
LOCAL_URL_DEFAULT="http://127.0.0.1:18789"
API_BASE_DEFAULT="http://127.0.0.1:3000"
AUTH_PATH_DEFAULT="/api/auth/login"

load_config() {
  if [ -f "$CONFIG_FILE" ]; then
    # shellcheck disable=SC1090
    . "$CONFIG_FILE"
  fi
}

url_encode() {
  python3 - "$1" <<'PY'
import sys
import urllib.parse
print(urllib.parse.quote(sys.argv[1], safe=''))
PY
}

ensure_cache_dir() {
  local cache_dir
  cache_dir="$(dirname "$CACHE_FILE")"
  mkdir -p "$cache_dir"
}

cache_token() {
  ensure_cache_dir
  python3 - "$CACHE_FILE" "$1" "$2" <<'PY'
import json
import os
import sys
from datetime import datetime, timezone

path = sys.argv[1]
token = sys.argv[2]
expires_at = sys.argv[3]

payload = {
    "token": token,
    "expires_at": int(expires_at) if expires_at else 0,
    "cached_at": int(datetime.now(timezone.utc).timestamp()),
}

os.makedirs(os.path.dirname(path), exist_ok=True)
with open(path, "w", encoding="utf-8") as f:
    json.dump(payload, f)
PY
}

read_cached_token() {
  if [ ! -f "$CACHE_FILE" ]; then
    return 1
  fi

  python3 - "$CACHE_FILE" <<'PY'
import json
import sys
from datetime import datetime, timezone

path = sys.argv[1]
now = int(datetime.now(timezone.utc).timestamp())

with open(path, "r", encoding="utf-8") as f:
    data = json.load(f)

token = data.get("token", "")
expires_at = int(data.get("expires_at", 0) or 0)

if not token:
    raise SystemExit(1)

if expires_at > 0 and now >= expires_at - 30:
    raise SystemExit(2)

print(token)
print(expires_at)
PY
}

parse_auth_response() {
  python3 - <<'PY'
import json
import os
import sys
from datetime import datetime, timezone

raw = os.environ.get("OPENCLAW_AUTH_RESPONSE", "")
if not raw:
    raise SystemExit(1)

data = json.loads(raw)

def pick(d, *paths):
    for path in paths:
        cur = d
        ok = True
        for p in path:
            if isinstance(cur, dict) and p in cur:
                cur = cur[p]
            else:
                ok = False
                break
        if ok and cur not in (None, ""):
            return cur
    return None

token = pick(
    data,
    ("access_token",),
    ("token",),
    ("data", "access_token"),
    ("data", "token"),
    ("result", "access_token"),
    ("result", "token"),
)

if not token:
    raise SystemExit(2)

now = int(datetime.now(timezone.utc).timestamp())
expires_at = 0

expires_at_raw = pick(
    data,
    ("expires_at",),
    ("expiresAt",),
    ("data", "expires_at"),
    ("data", "expiresAt"),
)
expires_in_raw = pick(
    data,
    ("expires_in",),
    ("expiresIn",),
    ("data", "expires_in"),
    ("data", "expiresIn"),
)

if expires_at_raw not in (None, ""):
    try:
        expires_at = int(expires_at_raw)
    except Exception:
        try:
            dt = datetime.fromisoformat(str(expires_at_raw).replace("Z", "+00:00"))
            expires_at = int(dt.timestamp())
        except Exception:
            expires_at = 0
elif expires_in_raw not in (None, ""):
    try:
        expires_at = now + int(float(expires_in_raw))
    except Exception:
        expires_at = 0

print(str(token))
print(str(expires_at))
PY
}

fetch_token_from_api() {
  local api_base auth_path auth_user_field auth_password_field
  local auth_username auth_password request_body response

  api_base="${OPENCLAW_API_BASE:-$API_BASE_DEFAULT}"
  auth_path="${OPENCLAW_AUTH_PATH:-$AUTH_PATH_DEFAULT}"
  auth_user_field="${OPENCLAW_AUTH_USER_FIELD:-email}"
  auth_password_field="${OPENCLAW_AUTH_PASSWORD_FIELD:-password}"
  auth_username="${OPENCLAW_AUTH_USERNAME:-}"
  auth_password="${OPENCLAW_AUTH_PASSWORD:-}"

  if [ -z "$auth_username" ] || [ -z "$auth_password" ]; then
    return 1
  fi

  request_body="$(python3 - "$auth_user_field" "$auth_password_field" "$auth_username" "$auth_password" <<'PY'
import json
import sys

uf = sys.argv[1]
pf = sys.argv[2]
u = sys.argv[3]
p = sys.argv[4]
print(json.dumps({uf: u, pf: p}))
PY
)"

  response="$(curl -fsS -X POST "${api_base%/}${auth_path}" -H "Content-Type: application/json" -d "$request_body" 2>/dev/null)" || return 1
  OPENCLAW_AUTH_RESPONSE="$response" parse_auth_response
}

fetch_token() {
  local cmd token
  cmd="${OPENCLAW_TOKEN_CMD:-}"

  if [ -n "$cmd" ]; then
    token="$(eval "$cmd" 2>/dev/null | tr -d '\r\n')"
    if [ -n "$token" ]; then
      printf "%s\n" "$token"
      printf "0\n"
      return 0
    fi
  fi

  fetch_token_from_api
}

get_local_url() {
  local local_url
  local_url="${OPENCLAW_LOCAL_URL:-$LOCAL_URL_DEFAULT}"
  printf "%s\n" "$local_url"
}

get_dashboard_base_url() {
  local dashboard_url
  dashboard_url="${OPENCLAW_DASHBOARD_URL:-}"
  if [ -z "$dashboard_url" ]; then
    dashboard_url="$(get_local_url)"
  fi
  printf "%s\n" "$dashboard_url"
}

get_control_url() {
  local control_url
  control_url="${OPENCLAW_CONTROL_URL:-$CONTROL_URL_DEFAULT}"
  if [ -z "$control_url" ]; then
    control_url="$(get_local_url)"
  fi
  printf "%s\n" "$control_url"
}

extract_port_from_url() {
  python3 - "$1" <<'PY'
import sys
from urllib.parse import urlparse

url = sys.argv[1].strip()
if not url:
    raise SystemExit(1)

if "://" not in url:
    url = "http://" + url

parsed = urlparse(url)
if parsed.port:
    print(parsed.port)
    raise SystemExit(0)

raise SystemExit(1)
PY
}

is_tunnel_running() {
  local status_cmd status_text lowered local_url local_port
  status_cmd="${OPENCLAW_TUNNEL_STATUS_CMD:-}"

  if [ -n "$status_cmd" ]; then
    if status_text="$(eval "$status_cmd" 2>/dev/null)"; then
      lowered="$(printf '%s' "$status_text" | tr '[:upper:]' '[:lower:]')"
      case "$lowered" in
        *stopped*|*stop*|*false*|*inactive*|*down*)
          return 1
          ;;
        0)
          return 1
          ;;
      esac
      return 0
    fi
    return 1
  fi

  local_url="$(get_local_url)"
  local_port="$(extract_port_from_url "$local_url" 2>/dev/null || true)"
  if [ -z "$local_port" ]; then
    return 1
  fi

  if command -v lsof >/dev/null 2>&1; then
    lsof -iTCP:"$local_port" -sTCP:LISTEN >/dev/null 2>&1
    return $?
  fi

  if command -v nc >/dev/null 2>&1; then
    nc -z 127.0.0.1 "$local_port" >/dev/null 2>&1
    return $?
  fi

  return 1
}

start_tunnel() {
  local start_cmd wait_seconds
  start_cmd="${OPENCLAW_TUNNEL_START_CMD:-}"
  if [ -z "$start_cmd" ]; then
    return 1
  fi

  eval "$start_cmd" >/dev/null 2>&1 || return 1
  wait_seconds="${OPENCLAW_TUNNEL_START_WAIT:-1}"
  sleep "$wait_seconds" >/dev/null 2>&1 || sleep 1
  is_tunnel_running
}

stop_tunnel() {
  local stop_cmd
  stop_cmd="${OPENCLAW_TUNNEL_STOP_CMD:-}"
  if [ -z "$stop_cmd" ]; then
    return 1
  fi

  eval "$stop_cmd" >/dev/null 2>&1 || return 1
  return 0
}

ensure_tunnel_running() {
  if is_tunnel_running; then
    return 0
  fi

  if [ "${OPENCLAW_AUTO_START_TUNNEL:-1}" = "1" ]; then
    start_tunnel && return 0
  fi

  return 1
}

get_token() {
  local token expires_at fetched

  if cached="$(read_cached_token 2>/dev/null)"; then
    token="$(printf '%s' "$cached" | sed -n '1p')"
    expires_at="$(printf '%s' "$cached" | sed -n '2p')"
    printf "%s\n" "$token"
    printf "%s\n" "$expires_at"
    return 0
  fi

  fetched="$(fetch_token 2>/dev/null)" || return 1
  token="$(printf '%s' "$fetched" | sed -n '1p')"
  expires_at="$(printf '%s' "$fetched" | sed -n '2p')"

  if [ -z "$token" ]; then
    return 1
  fi

  cache_token "$token" "$expires_at"
  printf "%s\n" "$token"
  printf "%s\n" "$expires_at"
}

build_dashboard_url() {
  local dashboard_url append_token query_key token encoded
  dashboard_url="$(get_dashboard_base_url)"
  if [ -z "$dashboard_url" ]; then
    dashboard_url="$DASHBOARD_URL_DEFAULT"
  fi
  append_token="${OPENCLAW_APPEND_TOKEN:-1}"
  query_key="${OPENCLAW_TOKEN_QUERY_KEY:-token}"
  token="$1"

  if [ "$append_token" != "1" ] || [ -z "$token" ]; then
    printf "%s\n" "$dashboard_url"
    return 0
  fi

  encoded="$(url_encode "$token")"
  if printf '%s' "$dashboard_url" | grep -q '?'; then
    printf "%s&%s=%s\n" "$dashboard_url" "$query_key" "$encoded"
  else
    printf "%s?%s=%s\n" "$dashboard_url" "$query_key" "$encoded"
  fi
}

copy_token_to_clipboard() {
  if command -v pbcopy >/dev/null 2>&1; then
    printf "%s" "$1" | pbcopy
  fi
}

notify() {
  local message
  message="$1"
  if command -v osascript >/dev/null 2>&1; then
    osascript -e "display notification \"${message//\"/\\\"}\" with title \"OpenClaw SwiftBar\"" >/dev/null 2>&1
  fi
}

action_open() {
  local token_data token dashboard

  ensure_tunnel_running || {
    notify "Tunnel 未运行，请检查 start/status 配置"
    exit 1
  }

  token_data="$(get_token)" || {
    notify "获取 auth token 失败，请检查配置"
    exit 1
  }

  token="$(printf '%s' "$token_data" | sed -n '1p')"
  dashboard="$(build_dashboard_url "$token")"

  copy_token_to_clipboard "$token"
  open "$dashboard" >/dev/null 2>&1
  notify "Dashboard 已打开，token 已复制"
}

action_open_control() {
  local control_url

  ensure_tunnel_running || {
    notify "Tunnel 未运行，请检查 start/status 配置"
    exit 1
  }

  control_url="$(get_control_url)"
  open "$control_url" >/dev/null 2>&1
  notify "Control UI 已打开"
}

action_start_tunnel() {
  if is_tunnel_running; then
    notify "Tunnel 已在运行"
    exit 0
  fi

  if start_tunnel; then
    notify "Tunnel 已启动"
  else
    notify "启动 Tunnel 失败，请检查 OPENCLAW_TUNNEL_START_CMD"
    exit 1
  fi
}

action_stop_tunnel() {
  if ! is_tunnel_running; then
    notify "Tunnel 未运行"
    exit 0
  fi

  if stop_tunnel; then
    notify "Tunnel 已停止"
  else
    notify "停止 Tunnel 失败，请检查 OPENCLAW_TUNNEL_STOP_CMD"
    exit 1
  fi
}

action_refresh_token() {
  local token_data token
  rm -f "$CACHE_FILE" >/dev/null 2>&1 || true
  token_data="$(get_token)" || {
    notify "刷新 token 失败"
    exit 1
  }
  token="$(printf '%s' "$token_data" | sed -n '1p')"
  copy_token_to_clipboard "$token"
  notify "token 已刷新并复制"
}

print_menu() {
  local status_text remote_label local_url

  if is_tunnel_running; then
    echo "🦞"
    status_text="Running ✅"
  else
    echo "🦞"
    status_text="Stopped ⛔"
  fi

  echo "---"
  echo "Status: ${status_text} | color=gray"
  echo "---"
  echo "Open UI (auto token) | bash='$0' param1=open_ui terminal=false refresh=true"
  echo "Open Control UI (no token) | bash='$0' param1=open_control terminal=false refresh=true"
  if is_tunnel_running; then
    echo "Stop Tunnel | bash='$0' param1=stop_tunnel terminal=false refresh=true"
  else
    echo "Start Tunnel | bash='$0' param1=start_tunnel terminal=false refresh=true"
  fi
  echo "---"

  remote_label="${OPENCLAW_REMOTE_LABEL:-未配置}"
  local_url="$(get_local_url)"
  echo "Remote: ${remote_label} | color=gray"
  echo "Local URL: ${local_url} | color=gray href=${local_url}"
  echo "Refresh | refresh=true"
}

main() {
  load_config
  case "${1:-}" in
    open_ui|open)
      action_open
      ;;
    open_control)
      action_open_control
      ;;
    start_tunnel)
      action_start_tunnel
      ;;
    stop_tunnel)
      action_stop_tunnel
      ;;
    refresh_token)
      action_refresh_token
      ;;
    *)
      print_menu
      ;;
  esac
}

main "${1:-}"
