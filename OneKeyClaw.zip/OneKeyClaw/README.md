# OpenClaw SwiftBar 插件

这个仓库提供一个 SwiftBar 插件：`openclaw.1m.sh`。

功能：
- 菜单状态显示（`Status: Running ✅ / Stopped ⛔`）
- `Open UI (auto token)`：自动取 token 并打开 UI
- `Open Control UI (no token)`：不带 token 打开控制台
- `Start Tunnel / Stop Tunnel`：隧道启停
- 自动获取 auth token（支持命令获取或登录接口获取）
- 打开时自动复制 token 到剪贴板
- `Remote` / `Local URL` 信息展示


## 一键安装（推荐）

在仓库根目录运行：

```bash
./install_openclaw.sh
```

脚本会：
- 复制插件到 SwiftBar 插件目录
- 生成 `~/.config/openclaw-swiftbar.env`
- 提示你填写账号/密码/接口地址

## 1. 安装

1. 将 `openclaw.1m.sh` 复制到你的 SwiftBar 插件目录（例如 `~/Library/Application Support/SwiftBar/Plugins/`）。
2. 给脚本可执行权限：

```bash
chmod +x "~/Library/Application Support/SwiftBar/Plugins/openclaw.1m.sh"
```

## 2. 配置

插件默认读取配置文件：`~/.config/openclaw-swiftbar.env`

示例：

```bash
# 本地隧道地址（菜单里的 Local URL）
OPENCLAW_LOCAL_URL="http://127.0.0.1:18789"

# Open UI 地址（不填则使用 OPENCLAW_LOCAL_URL）
OPENCLAW_DASHBOARD_URL="http://127.0.0.1:18789/ui"

# Open Control UI 地址（不填则使用 OPENCLAW_LOCAL_URL）
OPENCLAW_CONTROL_URL="http://127.0.0.1:18789"

# 菜单里的 Remote 显示文本
OPENCLAW_REMOTE_LABEL="steven@prod-cluster"

# 隧道控制命令
OPENCLAW_TUNNEL_STATUS_CMD="pgrep -f 'ssh.*18789' >/dev/null && echo running"
OPENCLAW_TUNNEL_START_CMD="/usr/local/bin/openclaw tunnel start"
OPENCLAW_TUNNEL_STOP_CMD="/usr/local/bin/openclaw tunnel stop"
OPENCLAW_TUNNEL_START_WAIT=1

# 点击 Open UI / Control UI 时，若 tunnel 未运行，是否自动尝试启动
OPENCLAW_AUTO_START_TUNNEL=1

# 方式 A：通过命令直接获取 token（优先级最高）
# OPENCLAW_TOKEN_CMD="security find-generic-password -a openclaw -s openclaw-token -w"

# 方式 B：通过登录接口换取 token
OPENCLAW_API_BASE="http://127.0.0.1:3000"
OPENCLAW_AUTH_PATH="/api/auth/login"
OPENCLAW_AUTH_USERNAME="you@example.com"
OPENCLAW_AUTH_PASSWORD="your_password"
OPENCLAW_AUTH_USER_FIELD="email"
OPENCLAW_AUTH_PASSWORD_FIELD="password"

# 是否把 token 追加到 URL 上（1 开启，0 关闭）
OPENCLAW_APPEND_TOKEN=1
OPENCLAW_TOKEN_QUERY_KEY="token"
```

## 3. 菜单说明

- `Open UI (auto token)`：自动取 token、复制 token、打开 UI。
- `Open Control UI (no token)`：直接打开控制台页面。
- `Start/Stop Tunnel`：执行你配置的 tunnel 启停命令。
- `Remote / Local URL`：显示当前隧道信息。
- `Refresh`：手动刷新菜单。



### 安装脚本输出示例

```text
SwiftBar plugins directory [/Users/you/Library/Application Support/SwiftBar/Plugins]:
Installed plugin to: /Users/you/Library/Application Support/SwiftBar/Plugins/openclaw.1m.sh
Creating config: /Users/you/.config/openclaw-swiftbar.env
Local URL [http://127.0.0.1:18789]:
Dashboard URL (blank to use Local URL) []:
Control URL (blank to use Local URL) []:
Remote label (shown in menu) []:
API base [http://127.0.0.1:3000]:
Auth path [/api/auth/login]:
Auth username (email) []:
Auth password []:

Config written. You can edit it later at: /Users/you/.config/openclaw-swiftbar.env

Next steps:
1) Open SwiftBar, and click Refresh.
2) If the plugin doesn't appear, ensure SwiftBar is running and the plugin dir is correct.
3) To uninstall later, run ./uninstall_swiftbar_openclaw.sh
```

### 发布打包说明

建议发布一个 zip：

```bash
zip -r openclaw-swiftbar.zip openclaw.1m.sh install_openclaw.sh uninstall_swiftbar_openclaw.sh README.md
```

用户只需解压后运行：

```bash
./install_openclaw.sh
```

## 卸载

只卸载 SwiftBar 插件与配置：

```bash
./uninstall_swiftbar_openclaw.sh
```

## 4. 缓存位置

默认缓存文件：`~/Library/Caches/SwiftBar/openclaw_token_cache.json`

可通过环境变量覆盖：

```bash
OPENCLAW_CACHE_FILE="/your/path/openclaw_token_cache.json"
```
