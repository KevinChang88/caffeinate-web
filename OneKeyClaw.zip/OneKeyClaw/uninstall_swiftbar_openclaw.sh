#!/usr/bin/env bash
set -euo pipefail

PLUGIN_NAME="openclaw.1m.sh"
SWIFTBAR_DIR_DEFAULT="$HOME/Library/Application Support/SwiftBar/Plugins"
CONFIG_FILE="$HOME/.config/openclaw-swiftbar.env"
CACHE_FILE="$HOME/Library/Caches/SwiftBar/openclaw_token_cache.json"

read -r -p "SwiftBar plugins directory [$SWIFTBAR_DIR_DEFAULT]: " SWIFTBAR_DIR
SWIFTBAR_DIR="${SWIFTBAR_DIR:-$SWIFTBAR_DIR_DEFAULT}"
PLUGIN_PATH="$SWIFTBAR_DIR/$PLUGIN_NAME"

read -r -p "Remove plugin $PLUGIN_PATH? (y/N): " CONFIRM
if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then
  if [ -f "$PLUGIN_PATH" ]; then
    rm -f "$PLUGIN_PATH"
    echo "Removed: $PLUGIN_PATH"
  else
    echo "Not found: $PLUGIN_PATH"
  fi
else
  echo "Skipped plugin removal."
fi

read -r -p "Remove config $CONFIG_FILE? (y/N): " CONFIRM
if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then
  if [ -f "$CONFIG_FILE" ]; then
    rm -f "$CONFIG_FILE"
    echo "Removed: $CONFIG_FILE"
  else
    echo "Not found: $CONFIG_FILE"
  fi
else
  echo "Skipped config removal."
fi

read -r -p "Remove cache $CACHE_FILE? (y/N): " CONFIRM
if [[ "$CONFIRM" == "y" || "$CONFIRM" == "Y" ]]; then
  if [ -f "$CACHE_FILE" ]; then
    rm -f "$CACHE_FILE"
    echo "Removed: $CACHE_FILE"
  else
    echo "Not found: $CACHE_FILE"
  fi
else
  echo "Skipped cache removal."
fi

echo "Done. If SwiftBar still shows the plugin, click Refresh or restart SwiftBar."
