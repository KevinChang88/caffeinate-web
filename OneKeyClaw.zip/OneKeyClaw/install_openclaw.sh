#!/usr/bin/env bash
set -euo pipefail

PLUGIN_NAME="openclaw.1m.sh"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_FILE="$SRC_DIR/$PLUGIN_NAME"

SWIFTBAR_DIR_DEFAULT="$HOME/Library/Application Support/SwiftBar/Plugins"
CONFIG_FILE="$HOME/.config/openclaw-swiftbar.env"
SWIFTBAR_APP_CANDIDATES=(
  "/Applications/SwiftBar.app"
  "$HOME/Applications/SwiftBar.app"
)

has_swiftbar_app() {
  local app_path
  for app_path in "${SWIFTBAR_APP_CANDIDATES[@]}"; do
    if [ -d "$app_path" ]; then
      return 0
    fi
  done
  return 1
}

maybe_install_swiftbar() {
  if has_swiftbar_app; then
    return 0
  fi

  echo "SwiftBar.app not found."
  echo "Install options:"
  echo "  1) brew install --cask swiftbar"
  echo "  2) open https://github.com/swiftbar/SwiftBar/releases/latest"
  echo "  3) skip installation"
  read -r -p "Choose [brew/open/skip]: " SWIFTBAR_INSTALL_CHOICE

  case "$SWIFTBAR_INSTALL_CHOICE" in
    brew)
      if command -v brew >/dev/null 2>&1; then
        brew install --cask swiftbar || true
      else
        echo "Homebrew not found. Install it first: https://brew.sh/"
      fi
      ;;
    open)
      if command -v open >/dev/null 2>&1; then
        open "https://github.com/swiftbar/SwiftBar/releases/latest"
      else
        echo "Cannot open browser automatically. Please visit:"
        echo "https://github.com/swiftbar/SwiftBar/releases/latest"
      fi
      ;;
    skip|"")
      ;;
    *)
      echo "Unknown choice. Skipping SwiftBar installation."
      ;;
  esac

  if ! has_swiftbar_app; then
    read -r -p "SwiftBar still not detected. Continue plugin install anyway? [y/N]: " CONTINUE_WITHOUT_SWIFTBAR
    if [ "${CONTINUE_WITHOUT_SWIFTBAR:-N}" != "y" ] && [ "${CONTINUE_WITHOUT_SWIFTBAR:-N}" != "Y" ]; then
      echo "Aborting. Install SwiftBar and re-run this script."
      exit 1
    fi
  fi
}

if [ ! -f "$SRC_FILE" ]; then
  echo "Error: $SRC_FILE not found. Run this script from the repo root." >&2
  exit 1
fi

maybe_install_swiftbar

read -r -p "SwiftBar plugins directory [$SWIFTBAR_DIR_DEFAULT]: " SWIFTBAR_DIR
SWIFTBAR_DIR="${SWIFTBAR_DIR:-$SWIFTBAR_DIR_DEFAULT}"

mkdir -p "$SWIFTBAR_DIR"
cp "$SRC_FILE" "$SWIFTBAR_DIR/$PLUGIN_NAME"
chmod +x "$SWIFTBAR_DIR/$PLUGIN_NAME"

echo "Installed plugin to: $SWIFTBAR_DIR/$PLUGIN_NAME"

if [ -f "$CONFIG_FILE" ]; then
  echo "Config already exists: $CONFIG_FILE"
  echo "Skipping config creation. Edit it manually if needed."
  exit 0
fi

echo "Creating config: $CONFIG_FILE"
mkdir -p "$(dirname "$CONFIG_FILE")"

read -r -p "Local URL [http://127.0.0.1:18789]: " OPENCLAW_LOCAL_URL
OPENCLAW_LOCAL_URL="${OPENCLAW_LOCAL_URL:-http://127.0.0.1:18789}"

read -r -p "Dashboard URL (blank to use Local URL) []: " OPENCLAW_DASHBOARD_URL
read -r -p "Control URL (blank to use Local URL) []: " OPENCLAW_CONTROL_URL
read -r -p "Remote label (shown in menu) []: " OPENCLAW_REMOTE_LABEL

read -r -p "API base [http://127.0.0.1:3000]: " OPENCLAW_API_BASE
OPENCLAW_API_BASE="${OPENCLAW_API_BASE:-http://127.0.0.1:3000}"

read -r -p "Auth path [/api/auth/login]: " OPENCLAW_AUTH_PATH
OPENCLAW_AUTH_PATH="${OPENCLAW_AUTH_PATH:-/api/auth/login}"

read -r -p "Auth username (email) []: " OPENCLAW_AUTH_USERNAME
read -r -s -p "Auth password []: " OPENCLAW_AUTH_PASSWORD

echo ""

cat <<EOF_CFG > "$CONFIG_FILE"
OPENCLAW_LOCAL_URL="$OPENCLAW_LOCAL_URL"
OPENCLAW_DASHBOARD_URL="$OPENCLAW_DASHBOARD_URL"
OPENCLAW_CONTROL_URL="$OPENCLAW_CONTROL_URL"
OPENCLAW_REMOTE_LABEL="$OPENCLAW_REMOTE_LABEL"

OPENCLAW_API_BASE="$OPENCLAW_API_BASE"
OPENCLAW_AUTH_PATH="$OPENCLAW_AUTH_PATH"
OPENCLAW_AUTH_USERNAME="$OPENCLAW_AUTH_USERNAME"
OPENCLAW_AUTH_PASSWORD="$OPENCLAW_AUTH_PASSWORD"

# Optional tunnel commands
# OPENCLAW_TUNNEL_STATUS_CMD="pgrep -f 'ssh.*18789' >/dev/null && echo running"
# OPENCLAW_TUNNEL_START_CMD="/usr/local/bin/openclaw tunnel start"
# OPENCLAW_TUNNEL_STOP_CMD="/usr/local/bin/openclaw tunnel stop"
# OPENCLAW_TUNNEL_START_WAIT=1

# OPENCLAW_AUTO_START_TUNNEL=1
# OPENCLAW_APPEND_TOKEN=1
# OPENCLAW_TOKEN_QUERY_KEY="token"
EOF_CFG

chmod 600 "$CONFIG_FILE"

echo "Config written. You can edit it later at: $CONFIG_FILE"

echo ""
echo "Next steps:"
echo "1) Open SwiftBar, and click Refresh."
echo "2) If the plugin doesn't appear, ensure SwiftBar is running and the plugin dir is correct."
echo "3) To uninstall later, run ./uninstall_swiftbar_openclaw.sh"
